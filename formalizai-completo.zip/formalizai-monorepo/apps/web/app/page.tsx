export { default } from "./(marketing)/landing";
